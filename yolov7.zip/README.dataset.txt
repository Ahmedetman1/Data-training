# ACC2025 > 2025-04-08 5:55pm
https://universe.roboflow.com/acc2025/acc2025-akyzb

Provided by a Roboflow user
License: CC BY 4.0

